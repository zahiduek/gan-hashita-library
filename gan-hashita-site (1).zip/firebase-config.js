// הגדרות החיבור ל-Firebase של הספרייה של גן השיטה
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyCSyj4fK75IHcXG1VdwqOobm9SBEBveKOs",
  authDomain: "gan-hashita-library-new.firebaseapp.com",
  databaseURL: "https://gan-hashita-library-new-default-rtdb.firebaseio.com",
  projectId: "gan-hashita-library-new",
  storageBucket: "gan-hashita-library-new.firebasestorage.app",
  messagingSenderId: "662328657479",
  appId: "1:662328657479:web:9da1cc06c862f680d61362"
};
// מספר הילדים בגן, לחישוב אחוזי הקריאה
window.APP_SETTINGS = { totalChildren: 34 };
