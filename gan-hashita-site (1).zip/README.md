# הספרייה של גן השיטה

אתר סטטי (HTML + JavaScript, בלי build, בלי התחברות). הנתונים נשמרים ב-Firebase Realtime Database, כמו בקייטנה, וכל ההורים רואים את אותה רשימה בזמן אמת.

## מצב הדגמה
פותחים את `index.html` כמו שהוא: הכול עובד, והנתונים נשמרים בדפדפן בלבד.

## חיבור ל-Firebase
1. ב-Firebase Console: Build -> Realtime Database -> Create database (אם עוד אין).
2. Realtime Database -> Rules: הדביקו את תוכן `database.rules.json` ולחצו Publish.
3. Project settings -> General -> Your apps -> Web app: העתיקו את ה-config אל `firebase-config.js` (כולל databaseURL מלשונית Realtime Database).
4. העלו את כל הקבצים, כולל התיקייה `assets`, לריפו ב-GitHub והפעילו Pages (Settings -> Pages).

## הערה
כל מי שיש לו את הקישור יכול לראות ולערוך את הרשימה. הכללים מגבילים רק את מבנה הנתונים (שם ילד, שם ספר ותאריכים).

## מבנה נתונים
`loans/{id}`: childName, bookTitle, loanDate, dueDate, returnDate, createdAt
